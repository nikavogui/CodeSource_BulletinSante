﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Labo_Bulletin
{
    public partial class FormLOGIN : System.Windows.Forms.Form
    {
        ClassLOGIN classLOGIN = new ClassLOGIN();
        public FormLOGIN()
        {
            InitializeComponent();
        }

        private void FormLOGIN_FormClosed(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void FormLOGIN_Load_1(object sender, EventArgs e)
        {
            dateTimePickerDATEEXPIRATION.Value = DateTime.Today;
            DateTime expiration = Convert.ToDateTime("31/01/2050");
            int valeur = expiration.CompareTo(dateTimePickerDATEEXPIRATION.Value);
            if (valeur == -1)
            {
                textBoxPW.Visible = false;
                textBoxUSERNAME.Visible = false;
                buttonCONNEXION.Visible = false;
                buttonQUITTER.Visible = false;
                panel4.Visible = true;
                label4.Visible = false;
                label3.Visible = false;
                //label5.Visible = false;

            }
            else
            {
                textBoxPW.Select();
                textBoxUSERNAME.Text = "Dr DIALLO";
                textBoxPW.Text = "";
                textBoxPW.Visible = true;
                textBoxUSERNAME.Visible = true;
                buttonCONNEXION.Visible = true;
                buttonQUITTER.Visible = true;
                panel4.Visible = false;
                label4.Visible = true;
                label3.Visible = true;
                //label5.Visible = true;
            }
        }

        private void buttonQUITTER_Click_1(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void buttonCONNEXION_Click(object sender, EventArgs e)
        {
            try
            {
                string user = textBoxUSERNAME.Text;
                string pw = textBoxPW.Text;
                DataTable utilisateur = classLOGIN.UserConnexion(user, pw);
                string droit = utilisateur.Rows[0][7].ToString();
                //MessageBox.Show(utilisateur.Rows.Count.ToString());
                if (utilisateur.Rows.Count > 0)
                {
                    if (droit.Trim().Equals("Administrateur"))
                    {
                        //MessageBox.Show("ADMINISTRATEUR");
                        FormMENUGENERAL formMENUGENERAL = new FormMENUGENERAL();
                        this.Hide();
                        formMENUGENERAL.ShowDialog();
                    }
                    else
                    {
                        //MessageBox.Show("UTILISATEUR");
                        FormMENUGENERAL formMENUGENERAL = new FormMENUGENERAL();
                        this.Hide();
                        formMENUGENERAL.ShowDialog();
                    }
                }
                else
                {
                    MessageBox.Show("NOM UTILISATEUR OU MOT DE PASSE INCORRECT", "USERNAME OU PASSWORD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxUSERNAME.Text = " Dr DIALLO";
                    textBoxPW.Text = "";
                    textBoxPW.Select();
                }


            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "EXCEPTION ERREUR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                MessageBox.Show("NOM UTILISATEUR OU MOT DE PASSE INCORRECT", "USERNAME OU PASSWORD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBoxUSERNAME.Text = "Dr DIALLO";
                textBoxPW.Text = "";
                textBoxPW.Select();
            }
        }

        private void FormLOGIN_FormClosed_1(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
