﻿namespace Labo_Bulletin
{
    partial class FormMENUGENERAL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMENUGENERAL));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBoxPULSATION = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxPOIDS = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxTENSION = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxTEMPERATURE = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxAGE = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBoxGENRE = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.maskedTextBoxTELEPHONE = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxPRENOMS = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxNOM = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxCODEPATIENT = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelSUPPRESSIONPRETE = new System.Windows.Forms.Label();
            this.dataGridViewLISTEEXAMENS = new System.Windows.Forms.DataGridView();
            this.textBoxIDRESULTAT = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonLISTEPARAMETRE = new System.Windows.Forms.Button();
            this.buttonAJOUTER = new System.Windows.Forms.Button();
            this.buttonANNULER = new System.Windows.Forms.Button();
            this.textBoxOBSERVATION = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.comboBoxRESULTAT = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.comboBoxEXAMEN = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.comboBoxNORME = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBoxTITRAGE = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBoxNOMPARAMETRE = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBoxCODEPARAMETRE = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.buttonBULLETIN = new System.Windows.Forms.Button();
            this.buttonSUPPRIMER = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLISTEEXAMENS)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.textBoxPULSATION);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.textBoxPOIDS);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.textBoxTENSION);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.textBoxTEMPERATURE);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.textBoxAGE);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.comboBoxGENRE);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.maskedTextBoxTELEPHONE);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBoxPRENOMS);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.textBoxNOM);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBoxCODEPATIENT);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 10.25F, System.Drawing.FontStyle.Bold);
            this.groupBox1.Location = new System.Drawing.Point(12, 80);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1007, 108);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "PATIENTS";
            // 
            // button4
            // 
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.Location = new System.Drawing.Point(496, 81);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(91, 22);
            this.button4.TabIndex = 41;
            this.button4.Text = "Supprimer";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Location = new System.Drawing.Point(593, 81);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(91, 22);
            this.button3.TabIndex = 40;
            this.button3.Text = "Modifier";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Location = new System.Drawing.Point(690, 81);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(154, 22);
            this.button2.TabIndex = 39;
            this.button2.Text = "NOUVEAU PATIENT";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Location = new System.Drawing.Point(850, 81);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(154, 22);
            this.button1.TabIndex = 38;
            this.button1.Text = "LISTE DES PATIENTS";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBoxPULSATION
            // 
            this.textBoxPULSATION.Location = new System.Drawing.Point(850, 52);
            this.textBoxPULSATION.Name = "textBoxPULSATION";
            this.textBoxPULSATION.Size = new System.Drawing.Size(109, 23);
            this.textBoxPULSATION.TabIndex = 19;
            this.textBoxPULSATION.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(755, 58);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 16);
            this.label10.TabIndex = 18;
            this.label10.Text = "PULSATION:";
            // 
            // textBoxPOIDS
            // 
            this.textBoxPOIDS.Location = new System.Drawing.Point(642, 55);
            this.textBoxPOIDS.Name = "textBoxPOIDS";
            this.textBoxPOIDS.Size = new System.Drawing.Size(109, 23);
            this.textBoxPOIDS.TabIndex = 17;
            this.textBoxPOIDS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(590, 58);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 16);
            this.label9.TabIndex = 16;
            this.label9.Text = "POIDS:";
            // 
            // textBoxTENSION
            // 
            this.textBoxTENSION.Location = new System.Drawing.Point(473, 55);
            this.textBoxTENSION.Name = "textBoxTENSION";
            this.textBoxTENSION.Size = new System.Drawing.Size(109, 23);
            this.textBoxTENSION.TabIndex = 15;
            this.textBoxTENSION.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(404, 58);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 16);
            this.label8.TabIndex = 14;
            this.label8.Text = "TENSION:";
            // 
            // textBoxTEMPERATURE
            // 
            this.textBoxTEMPERATURE.Location = new System.Drawing.Point(290, 55);
            this.textBoxTEMPERATURE.Name = "textBoxTEMPERATURE";
            this.textBoxTEMPERATURE.Size = new System.Drawing.Size(109, 23);
            this.textBoxTEMPERATURE.TabIndex = 13;
            this.textBoxTEMPERATURE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(170, 58);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 16);
            this.label7.TabIndex = 12;
            this.label7.Text = "TEMPERATURE:";
            // 
            // textBoxAGE
            // 
            this.textBoxAGE.Location = new System.Drawing.Point(55, 52);
            this.textBoxAGE.Name = "textBoxAGE";
            this.textBoxAGE.Size = new System.Drawing.Size(109, 23);
            this.textBoxAGE.TabIndex = 11;
            this.textBoxAGE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 55);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "AGE:";
            // 
            // comboBoxGENRE
            // 
            this.comboBoxGENRE.FormattingEnabled = true;
            this.comboBoxGENRE.Items.AddRange(new object[] {
            "M",
            "F"});
            this.comboBoxGENRE.Location = new System.Drawing.Point(919, 18);
            this.comboBoxGENRE.Name = "comboBoxGENRE";
            this.comboBoxGENRE.Size = new System.Drawing.Size(72, 24);
            this.comboBoxGENRE.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(853, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "GENRE:";
            // 
            // maskedTextBoxTELEPHONE
            // 
            this.maskedTextBoxTELEPHONE.Location = new System.Drawing.Point(749, 15);
            this.maskedTextBoxTELEPHONE.Mask = "000 00 00 00";
            this.maskedTextBoxTELEPHONE.Name = "maskedTextBoxTELEPHONE";
            this.maskedTextBoxTELEPHONE.Size = new System.Drawing.Size(98, 23);
            this.maskedTextBoxTELEPHONE.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(648, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "TELEPHONE:";
            // 
            // textBoxPRENOMS
            // 
            this.textBoxPRENOMS.Location = new System.Drawing.Point(492, 16);
            this.textBoxPRENOMS.Name = "textBoxPRENOMS";
            this.textBoxPRENOMS.Size = new System.Drawing.Size(153, 23);
            this.textBoxPRENOMS.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(403, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "PRENOMS:";
            // 
            // textBoxNOM
            // 
            this.textBoxNOM.Location = new System.Drawing.Point(243, 16);
            this.textBoxNOM.Name = "textBoxNOM";
            this.textBoxNOM.Size = new System.Drawing.Size(148, 23);
            this.textBoxNOM.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(191, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "NOM:";
            // 
            // textBoxCODEPATIENT
            // 
            this.textBoxCODEPATIENT.Location = new System.Drawing.Point(56, 16);
            this.textBoxCODEPATIENT.Name = "textBoxCODEPATIENT";
            this.textBoxCODEPATIENT.Size = new System.Drawing.Size(129, 23);
            this.textBoxCODEPATIENT.TabIndex = 1;
            this.textBoxCODEPATIENT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxCODEPATIENT.Leave += new System.EventHandler(this.textBoxCODEPATIENT_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "CODE:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.labelSUPPRESSIONPRETE);
            this.panel1.Controls.Add(this.dataGridViewLISTEEXAMENS);
            this.panel1.Controls.Add(this.textBoxIDRESULTAT);
            this.panel1.Font = new System.Drawing.Font("Arial", 10.25F, System.Drawing.FontStyle.Bold);
            this.panel1.Location = new System.Drawing.Point(12, 499);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1011, 179);
            this.panel1.TabIndex = 1;
            // 
            // labelSUPPRESSIONPRETE
            // 
            this.labelSUPPRESSIONPRETE.AutoSize = true;
            this.labelSUPPRESSIONPRETE.Location = new System.Drawing.Point(402, 157);
            this.labelSUPPRESSIONPRETE.Name = "labelSUPPRESSIONPRETE";
            this.labelSUPPRESSIONPRETE.Size = new System.Drawing.Size(0, 16);
            this.labelSUPPRESSIONPRETE.TabIndex = 38;
            // 
            // dataGridViewLISTEEXAMENS
            // 
            this.dataGridViewLISTEEXAMENS.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewLISTEEXAMENS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLISTEEXAMENS.Location = new System.Drawing.Point(3, 1);
            this.dataGridViewLISTEEXAMENS.Name = "dataGridViewLISTEEXAMENS";
            this.dataGridViewLISTEEXAMENS.ReadOnly = true;
            this.dataGridViewLISTEEXAMENS.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewLISTEEXAMENS.Size = new System.Drawing.Size(1004, 154);
            this.dataGridViewLISTEEXAMENS.TabIndex = 0;
            this.dataGridViewLISTEEXAMENS.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewLISTEEXAMENS_CellClick);
            // 
            // textBoxIDRESULTAT
            // 
            this.textBoxIDRESULTAT.Location = new System.Drawing.Point(15, 35);
            this.textBoxIDRESULTAT.Name = "textBoxIDRESULTAT";
            this.textBoxIDRESULTAT.Size = new System.Drawing.Size(109, 23);
            this.textBoxIDRESULTAT.TabIndex = 42;
            this.textBoxIDRESULTAT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 48.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label11.Location = new System.Drawing.Point(131, 191);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(748, 77);
            this.label11.TabIndex = 2;
            this.label11.Text = "EXAMENS DU PATIENT";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 48.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label12.Location = new System.Drawing.Point(55, -3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(926, 77);
            this.label12.TabIndex = 3;
            this.label12.Text = "INFORMATIONS DU PATIENT";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.buttonLISTEPARAMETRE);
            this.groupBox2.Controls.Add(this.buttonAJOUTER);
            this.groupBox2.Controls.Add(this.buttonANNULER);
            this.groupBox2.Controls.Add(this.textBoxOBSERVATION);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.comboBoxRESULTAT);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.comboBoxEXAMEN);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.comboBoxNORME);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.comboBoxTITRAGE);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.comboBoxNOMPARAMETRE);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.comboBoxCODEPARAMETRE);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 10.25F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(13, 271);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1007, 160);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "EXAMENS";
            // 
            // buttonLISTEPARAMETRE
            // 
            this.buttonLISTEPARAMETRE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonLISTEPARAMETRE.Location = new System.Drawing.Point(808, 129);
            this.buttonLISTEPARAMETRE.Name = "buttonLISTEPARAMETRE";
            this.buttonLISTEPARAMETRE.Size = new System.Drawing.Size(193, 22);
            this.buttonLISTEPARAMETRE.TabIndex = 37;
            this.buttonLISTEPARAMETRE.Text = "LISTE DES PARAMETRES";
            this.buttonLISTEPARAMETRE.UseVisualStyleBackColor = true;
            this.buttonLISTEPARAMETRE.Click += new System.EventHandler(this.buttonLISTEPARAMETRE_Click);
            // 
            // buttonAJOUTER
            // 
            this.buttonAJOUTER.BackColor = System.Drawing.Color.Green;
            this.buttonAJOUTER.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAJOUTER.ForeColor = System.Drawing.Color.White;
            this.buttonAJOUTER.Location = new System.Drawing.Point(517, 126);
            this.buttonAJOUTER.Name = "buttonAJOUTER";
            this.buttonAJOUTER.Size = new System.Drawing.Size(117, 28);
            this.buttonAJOUTER.TabIndex = 34;
            this.buttonAJOUTER.Text = "Ajouter";
            this.buttonAJOUTER.UseVisualStyleBackColor = false;
            this.buttonAJOUTER.Click += new System.EventHandler(this.buttonAJOUTER_Click);
            // 
            // buttonANNULER
            // 
            this.buttonANNULER.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.buttonANNULER.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonANNULER.ForeColor = System.Drawing.Color.White;
            this.buttonANNULER.Location = new System.Drawing.Point(641, 126);
            this.buttonANNULER.Name = "buttonANNULER";
            this.buttonANNULER.Size = new System.Drawing.Size(117, 28);
            this.buttonANNULER.TabIndex = 33;
            this.buttonANNULER.Text = "Annuler";
            this.buttonANNULER.UseVisualStyleBackColor = false;
            this.buttonANNULER.Click += new System.EventHandler(this.buttonANNULER_Click);
            // 
            // textBoxOBSERVATION
            // 
            this.textBoxOBSERVATION.Location = new System.Drawing.Point(126, 79);
            this.textBoxOBSERVATION.Multiline = true;
            this.textBoxOBSERVATION.Name = "textBoxOBSERVATION";
            this.textBoxOBSERVATION.Size = new System.Drawing.Size(385, 75);
            this.textBoxOBSERVATION.TabIndex = 22;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(11, 79);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(110, 16);
            this.label19.TabIndex = 32;
            this.label19.Text = "OBSERVATION:";
            // 
            // comboBoxRESULTAT
            // 
            this.comboBoxRESULTAT.FormattingEnabled = true;
            this.comboBoxRESULTAT.Items.AddRange(new object[] {
            "(-) NEGATIF",
            "(+) POSITIF",
            "A+",
            "AB+",
            "B+",
            "O+",
            "A-",
            "AB-",
            "B-",
            "O-",
            "AGP",
            "NEANT"});
            this.comboBoxRESULTAT.Location = new System.Drawing.Point(340, 50);
            this.comboBoxRESULTAT.Name = "comboBoxRESULTAT";
            this.comboBoxRESULTAT.Size = new System.Drawing.Size(171, 24);
            this.comboBoxRESULTAT.TabIndex = 21;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(257, 54);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(78, 16);
            this.label18.TabIndex = 30;
            this.label18.Text = "RESULTAT:";
            // 
            // comboBoxEXAMEN
            // 
            this.comboBoxEXAMEN.Enabled = false;
            this.comboBoxEXAMEN.FormattingEnabled = true;
            this.comboBoxEXAMEN.Location = new System.Drawing.Point(83, 49);
            this.comboBoxEXAMEN.Name = "comboBoxEXAMEN";
            this.comboBoxEXAMEN.Size = new System.Drawing.Size(171, 24);
            this.comboBoxEXAMEN.TabIndex = 29;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(11, 53);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(71, 16);
            this.label17.TabIndex = 28;
            this.label17.Text = "EXAMEN:";
            // 
            // comboBoxNORME
            // 
            this.comboBoxNORME.Enabled = false;
            this.comboBoxNORME.FormattingEnabled = true;
            this.comboBoxNORME.Location = new System.Drawing.Point(830, 19);
            this.comboBoxNORME.Name = "comboBoxNORME";
            this.comboBoxNORME.Size = new System.Drawing.Size(171, 24);
            this.comboBoxNORME.TabIndex = 27;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(758, 23);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 16);
            this.label16.TabIndex = 26;
            this.label16.Text = "NORME:";
            // 
            // comboBoxTITRAGE
            // 
            this.comboBoxTITRAGE.Enabled = false;
            this.comboBoxTITRAGE.FormattingEnabled = true;
            this.comboBoxTITRAGE.Location = new System.Drawing.Point(574, 20);
            this.comboBoxTITRAGE.Name = "comboBoxTITRAGE";
            this.comboBoxTITRAGE.Size = new System.Drawing.Size(176, 24);
            this.comboBoxTITRAGE.TabIndex = 25;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(502, 26);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 16);
            this.label15.TabIndex = 24;
            this.label15.Text = "TITRAGE:";
            // 
            // comboBoxNOMPARAMETRE
            // 
            this.comboBoxNOMPARAMETRE.Enabled = false;
            this.comboBoxNOMPARAMETRE.FormattingEnabled = true;
            this.comboBoxNOMPARAMETRE.Location = new System.Drawing.Point(343, 20);
            this.comboBoxNOMPARAMETRE.Name = "comboBoxNOMPARAMETRE";
            this.comboBoxNOMPARAMETRE.Size = new System.Drawing.Size(153, 24);
            this.comboBoxNOMPARAMETRE.TabIndex = 23;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(240, 23);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(97, 16);
            this.label14.TabIndex = 22;
            this.label14.Text = "PARAMETRE:";
            // 
            // comboBoxCODEPARAMETRE
            // 
            this.comboBoxCODEPARAMETRE.FormattingEnabled = true;
            this.comboBoxCODEPARAMETRE.Location = new System.Drawing.Point(155, 20);
            this.comboBoxCODEPARAMETRE.Name = "comboBoxCODEPARAMETRE";
            this.comboBoxCODEPARAMETRE.Size = new System.Drawing.Size(81, 24);
            this.comboBoxCODEPARAMETRE.TabIndex = 20;
            this.comboBoxCODEPARAMETRE.TextChanged += new System.EventHandler(this.comboBoxCODEPARAMETRE_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(8, 23);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(141, 16);
            this.label13.TabIndex = 20;
            this.label13.Text = "CODE PARAMETRE:";
            // 
            // buttonBULLETIN
            // 
            this.buttonBULLETIN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonBULLETIN.Location = new System.Drawing.Point(849, 460);
            this.buttonBULLETIN.Name = "buttonBULLETIN";
            this.buttonBULLETIN.Size = new System.Drawing.Size(170, 34);
            this.buttonBULLETIN.TabIndex = 20;
            this.buttonBULLETIN.Text = "BULLETIN";
            this.buttonBULLETIN.UseVisualStyleBackColor = true;
            this.buttonBULLETIN.Click += new System.EventHandler(this.buttonBULLETIN_Click);
            // 
            // buttonSUPPRIMER
            // 
            this.buttonSUPPRIMER.BackColor = System.Drawing.Color.Red;
            this.buttonSUPPRIMER.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSUPPRIMER.Font = new System.Drawing.Font("Arial", 10.25F, System.Drawing.FontStyle.Bold);
            this.buttonSUPPRIMER.ForeColor = System.Drawing.Color.White;
            this.buttonSUPPRIMER.Location = new System.Drawing.Point(15, 465);
            this.buttonSUPPRIMER.Name = "buttonSUPPRIMER";
            this.buttonSUPPRIMER.Size = new System.Drawing.Size(94, 28);
            this.buttonSUPPRIMER.TabIndex = 35;
            this.buttonSUPPRIMER.Text = "Supprimer";
            this.buttonSUPPRIMER.UseVisualStyleBackColor = false;
            this.buttonSUPPRIMER.Click += new System.EventHandler(this.buttonSUPPRIMER_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 30.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label20.Location = new System.Drawing.Point(186, 449);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(640, 47);
            this.label20.TabIndex = 36;
            this.label20.Text = "LISTE DES EXAMENS AJOUTES";
            // 
            // FormMENUGENERAL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(1035, 680);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.buttonSUPPRIMER);
            this.Controls.Add(this.buttonBULLETIN);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.Name = "FormMENUGENERAL";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MENU GENERAL";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormMENUGENERAL_FormClosed);
            this.Load += new System.EventHandler(this.FormMENUGENERAL_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLISTEEXAMENS)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBoxPULSATION;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxPOIDS;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxTENSION;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxTEMPERATURE;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxAGE;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBoxGENRE;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxTELEPHONE;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxPRENOMS;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxNOM;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxCODEPATIENT;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonAJOUTER;
        private System.Windows.Forms.Button buttonANNULER;
        private System.Windows.Forms.TextBox textBoxOBSERVATION;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox comboBoxRESULTAT;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox comboBoxEXAMEN;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox comboBoxNORME;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox comboBoxTITRAGE;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBoxNOMPARAMETRE;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBoxCODEPARAMETRE;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button buttonBULLETIN;
        private System.Windows.Forms.Button buttonSUPPRIMER;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button buttonLISTEPARAMETRE;
        private System.Windows.Forms.DataGridView dataGridViewLISTEEXAMENS;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label labelSUPPRESSIONPRETE;
        private System.Windows.Forms.TextBox textBoxIDRESULTAT;
    }
}