﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;

namespace Labo_Bulletin
{
    
    class ClassPATIENTS
    {
        ClassCONNEXION con = new ClassCONNEXION();
        public DataTable codeParametre()
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "SELECT DISTINCT idParam FROM cliniquesolange.parametres ORDER BY idParam;";
            command.Connection = con.GetConnection();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            adapter.SelectCommand = command;
            DataTable data = new DataTable();
            adapter.Fill(data);
            return data;
        }
        public DataTable InfoParametre(int codeParam)
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "SELECT idParam as 'CODE PARAMETRE', parametre as PARAMETRE, `types` as TITRAGE, norme as NORME, examen as EXAMEN FROM cliniquesolange.parametres WHERE idParam=@code;";
            command.Connection = con.GetConnection();
            command.Parameters.Add("@code", MySqlDbType.Int32).Value = codeParam;
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            adapter.SelectCommand = command;
            DataTable data = new DataTable();
            adapter.Fill(data);
            return data;
        }
        public DataTable examenPatient(int codePatient)
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "SELECT idResultat as 'ID',codeParam as 'CODE PARAMETRE', parametre as PARAMETRE, `type` as TITRAGE, norme as NORME, examen as EXAMEN, resultat as RESULTAT, obs as OBSERVATION, codePatient as 'CODE PATIENT' FROM cliniquesolange.resultats WHERE codePatient=@patient;";
            command.Connection = con.GetConnection();
            command.Parameters.Add("@patient", MySqlDbType.Int32).Value = codePatient;
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            adapter.SelectCommand = command;
            DataTable data = new DataTable();
            adapter.Fill(data);
            return data;
        }
        public bool ajoutPatient(string nom, string prenoms, string tel, string genre, string age, string temperature, string tension, string poids, string pulsation)
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "INSERT INTO `cliniquesolange`.`patients` VALUES (codePatient,@nom,@prenoms,@tel,@genre,@age,@temperature,@tension,@poids,@pulsation);";
            command.Connection = con.GetConnection();
            //VALUES(id, @nom, @prenoms, @genre, @diplome, @poste, @dateNaissance, @tel, @salaireBrute, @dateEmbauche);
            command.Parameters.Add("@nom", MySqlDbType.VarChar).Value = nom;
            command.Parameters.Add("@prenoms", MySqlDbType.VarChar).Value = prenoms;
            command.Parameters.Add("@genre", MySqlDbType.VarChar).Value = genre;
            command.Parameters.Add("@age", MySqlDbType.VarChar).Value = age;
            command.Parameters.Add("@temperature", MySqlDbType.VarChar).Value = temperature;
            command.Parameters.Add("@tension", MySqlDbType.VarChar).Value = tension;
            command.Parameters.Add("@tel", MySqlDbType.VarChar).Value = tel;
            command.Parameters.Add("@poids", MySqlDbType.VarChar).Value = poids;
            command.Parameters.Add("@pulsation", MySqlDbType.VarChar).Value = pulsation;

            con.openConnection();
            if (command.ExecuteNonQuery() == 1)
            {
                con.closeConnection();
                return true;
            }
            else
            {
                con.closeConnection();
                return false;
            }

        }

        public bool modifierPatient(int codePatient,string nom, string prenoms, string tel, string genre, string age, string temperature, string tension, string poids, string pulsation)
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "UPDATE `cliniquesolange`.`patients` SET nom=@nom,prenoms=@prenoms,tel=@tel,sexe=@genre,age=@age,temperature=@temperature,tension=@tension,poids=@poids,pulsation=@pulsation WHERE codePatient=@id;";
            command.Connection = con.GetConnection();
            //VALUES(id, @nom, @prenoms, @genre, @diplome, @poste, @dateNaissance, @tel, @salaireBrute, @dateEmbauche);
            command.Parameters.Add("@id", MySqlDbType.Int32).Value = codePatient;
            command.Parameters.Add("@nom", MySqlDbType.VarChar).Value = nom;
            command.Parameters.Add("@prenoms", MySqlDbType.VarChar).Value = prenoms;
            command.Parameters.Add("@genre", MySqlDbType.VarChar).Value = genre;
            command.Parameters.Add("@age", MySqlDbType.VarChar).Value = age;
            command.Parameters.Add("@temperature", MySqlDbType.VarChar).Value = temperature;
            command.Parameters.Add("@tension", MySqlDbType.VarChar).Value = tension;
            command.Parameters.Add("@tel", MySqlDbType.VarChar).Value = tel;
            command.Parameters.Add("@poids", MySqlDbType.VarChar).Value = poids;
            command.Parameters.Add("@pulsation", MySqlDbType.VarChar).Value = pulsation;

            con.openConnection();
            if (command.ExecuteNonQuery() == 1)
            {
                con.closeConnection();
                return true;
            }
            else
            {
                con.closeConnection();
                return false;
            }

        }

        public bool ajoutResultat(int codePatient,int codeParam,string parametre, string type, string norme, string examen, string resultat, string obs)
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "INSERT INTO `cliniquesolange`.`resultats` VALUES (idResultat,@codePatient,@codeParam,@parametre,@type,@norme,@examen,@resultat,@obs);";
            command.Connection = con.GetConnection();
            //VALUES(id, @nom, @prenoms, @genre, @diplome, @poste, @dateNaissance, @tel, @salaireBrute, @dateEmbauche);
            command.Parameters.Add("@codePatient", MySqlDbType.Int32).Value = codePatient;
            command.Parameters.Add("@codeParam", MySqlDbType.Int32).Value = codeParam;
            command.Parameters.Add("@parametre", MySqlDbType.VarChar).Value = parametre;
            command.Parameters.Add("@type", MySqlDbType.VarChar).Value = type;
            command.Parameters.Add("@norme", MySqlDbType.VarChar).Value = norme;
            command.Parameters.Add("@examen", MySqlDbType.VarChar).Value = examen;
            command.Parameters.Add("@resultat", MySqlDbType.VarChar).Value = resultat;
            command.Parameters.Add("@obs", MySqlDbType.VarChar).Value = obs;

            con.openConnection();
            if (command.ExecuteNonQuery() == 1)
            {
                con.closeConnection();
                return true;
            }
            else
            {
                con.closeConnection();
                return false;
            }

        }

        public bool deletePATIENT(int id)
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "DELETE FROM `cliniquesolange`.`patients` WHERE codePatient=@id;";
            command.Connection = con.GetConnection();
            //VALUES(id, @nom, @prenoms, @genre, @diplome, @poste, @dateNaissance, @tel, @salaireBrute, @dateEmbauche);
            command.Parameters.Add("@id", MySqlDbType.Int32).Value = id;
            con.openConnection();
            if (command.ExecuteNonQuery() == 1)
            {
                con.closeConnection();
                return true;
            }
            else
            {
                con.closeConnection();
                return false;
            }

        }

        public bool deletePATIENTANDRESULTAT(int id)
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "DELETE FROM `cliniquesolange`.`resultats` WHERE codePatient=@id;";
            command.Connection = con.GetConnection();
            //VALUES(id, @nom, @prenoms, @genre, @diplome, @poste, @dateNaissance, @tel, @salaireBrute, @dateEmbauche);
            command.Parameters.Add("@id", MySqlDbType.Int32).Value = id;
            con.openConnection();
            if (command.ExecuteNonQuery() == 1)
            {
                con.closeConnection();
                return true;
            }
            else
            {
                con.closeConnection();
                return false;
            }

        }

        public bool deleteResultat(int id)
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "DELETE FROM `cliniquesolange`.`resultats` WHERE idResultat=@id;";
            command.Connection = con.GetConnection();
            //VALUES(id, @nom, @prenoms, @genre, @diplome, @poste, @dateNaissance, @tel, @salaireBrute, @dateEmbauche);
            command.Parameters.Add("@id", MySqlDbType.Int32).Value = id;
            con.openConnection();
            if (command.ExecuteNonQuery() == 1)
            {
                con.closeConnection();
                return true;
            }
            else
            {
                con.closeConnection();
                return false;
            }

        }

        public string codeDernierAjout()
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "SELECT max(codePatient) FROM patients";
            //command.Parameters.Add("@mois", MySqlDbType.Int32).Value = mois;
            command.Connection = con.GetConnection();
            con.openConnection();
            string dernierPatient = command.ExecuteScalar().ToString();
            return dernierPatient;
        }

        public DataTable DernierPatientAjout(int codePatient)
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "SELECT * FROM cliniquesolange.patients WHERE codePatient=@patient;";
            command.Connection = con.GetConnection();
            command.Parameters.Add("@patient", MySqlDbType.Int32).Value = codePatient;
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            adapter.SelectCommand = command;
            DataTable data = new DataTable();
            adapter.Fill(data);
            return data;
        }


    }
}
