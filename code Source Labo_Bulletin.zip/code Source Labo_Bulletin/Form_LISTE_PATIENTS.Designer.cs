﻿namespace Labo_Bulletin
{
    partial class Form_LISTE_PATIENTS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_LISTE_PATIENTS));
            this.crystalReportViewerBULLETINPAIEPERSO = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.SuspendLayout();
            // 
            // crystalReportViewerBULLETINPAIEPERSO
            // 
            this.crystalReportViewerBULLETINPAIEPERSO.ActiveViewIndex = -1;
            this.crystalReportViewerBULLETINPAIEPERSO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewerBULLETINPAIEPERSO.Cursor = System.Windows.Forms.Cursors.Default;
            this.crystalReportViewerBULLETINPAIEPERSO.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crystalReportViewerBULLETINPAIEPERSO.Location = new System.Drawing.Point(0, 0);
            this.crystalReportViewerBULLETINPAIEPERSO.Name = "crystalReportViewerBULLETINPAIEPERSO";
            this.crystalReportViewerBULLETINPAIEPERSO.Size = new System.Drawing.Size(800, 450);
            this.crystalReportViewerBULLETINPAIEPERSO.TabIndex = 1;
            this.crystalReportViewerBULLETINPAIEPERSO.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            // 
            // Form_LISTE_PATIENTS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.crystalReportViewerBULLETINPAIEPERSO);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_LISTE_PATIENTS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LISTE DES PATIENTS";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form_LISTE_PATIENTS_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewerBULLETINPAIEPERSO;
    }
}