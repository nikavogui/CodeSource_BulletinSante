﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using MySql.Data.MySqlClient;

namespace Labo_Bulletin
{
    public partial class Form_BULLETIN : Form
    {
        ClassCONNEXION con = new ClassCONNEXION();
        ReportDocument reportDocument = new ReportDocument();
        int codePatient;
        public Form_BULLETIN(int code)
        {
            codePatient = code;
            InitializeComponent();
            textBoxCODEPATIENT.Text = codePatient.ToString();
        }

        private void Form_BULLETIN_Load(object sender, EventArgs e)
        {
            try
            {

                //labelMOIS.Hide(); 
                //comboBoxMOIS.Hide();
                //MessageBox.Show(comboBoxMOIS.Text);
                reportDocument.Load(@"C:\Users\DELL\source\repos\Labo_Bulletin\Labo_Bulletin\EXAMENS\Bulletin.rpt");
                MySqlCommand command = new MySqlCommand();
                command.CommandText = "SELECT patients.codePatient, patients.nom, patients.prenoms, patients.tel, patients.sexe, patients.age, patients.temperature, patients.tension, patients.poids, patients.pulsation, resultats.codeParam, resultats.parametre,resultats.type, resultats.norme, resultats.examen, resultats.resultat, resultats.obs FROM patients INNER JOIN resultats ON patients.codePatient = resultats.codePatient WHERE patients.codePatient='"+Convert.ToInt32(textBoxCODEPATIENT.Text)+"';";
                //DateTime day1, day2;
                //day1 = Convert.ToDateTime(dateTimePickerDU.Value);
                //day2 = Convert.ToDateTime(dateTimePickerAU.Value);
                //command.Parameters.Add("@date1", MySqlDbType.Date).Value = day1;
                //command.Parameters.Add("@date2", MySqlDbType.Date).Value = day2;
                command.Connection = con.GetConnection();
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = command;
                DataSet bulletinPerso = new DataSet();
                adapter.Fill(bulletinPerso, "bulletin");
                reportDocument.SetDataSource(bulletinPerso);
                // ReportBulletinPaiePerso.SetParameterValue("@mois",comboBoxMOIS.Text);
                crystalReportViewerBULLETINPAIEPERSO.ReportSource = reportDocument;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
