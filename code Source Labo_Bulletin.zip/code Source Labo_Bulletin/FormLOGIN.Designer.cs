﻿namespace Labo_Bulletin
{
    partial class FormLOGIN
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormLOGIN));
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonQUITTER = new System.Windows.Forms.Button();
            this.buttonCONNEXION = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxPW = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxUSERNAME = new System.Windows.Forms.TextBox();
            this.dateTimePickerDATEEXPIRATION = new System.Windows.Forms.DateTimePicker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(18, 150);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(429, 23);
            this.label9.TabIndex = 7;
            this.label9.Text = "Veuillez Contacter le Developpeur SVP";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(55, 111);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(368, 23);
            this.label6.TabIndex = 6;
            this.label6.Text = "Powered by R-TECH GROUP SARL";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(18, 36);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(404, 23);
            this.label7.TabIndex = 5;
            this.label7.Text = "Email: jmnikavogui1992@gmail.com";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(1, 7);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(423, 23);
            this.label10.TabIndex = 3;
            this.label10.Text = "Developpeur: Jean Michel NIKAVOGUI";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Location = new System.Drawing.Point(12, 115);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(486, 220);
            this.panel4.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(97, 75);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(282, 23);
            this.label8.TabIndex = 4;
            this.label8.Text = "Telephone: 626-176-177";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label5.Font = new System.Drawing.Font("Arial", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label5.Location = new System.Drawing.Point(280, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(150, 16);
            this.label5.TabIndex = 6;
            this.label5.Text = "Mot de passe oublié";
            this.label5.Visible = false;
            // 
            // buttonQUITTER
            // 
            this.buttonQUITTER.BackColor = System.Drawing.Color.Maroon;
            this.buttonQUITTER.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonQUITTER.FlatAppearance.BorderColor = System.Drawing.Color.Maroon;
            this.buttonQUITTER.FlatAppearance.BorderSize = 0;
            this.buttonQUITTER.ForeColor = System.Drawing.Color.White;
            this.buttonQUITTER.Location = new System.Drawing.Point(278, 146);
            this.buttonQUITTER.Name = "buttonQUITTER";
            this.buttonQUITTER.Size = new System.Drawing.Size(131, 43);
            this.buttonQUITTER.TabIndex = 5;
            this.buttonQUITTER.Text = "Quitter";
            this.buttonQUITTER.UseVisualStyleBackColor = false;
            this.buttonQUITTER.Click += new System.EventHandler(this.buttonQUITTER_Click_1);
            // 
            // buttonCONNEXION
            // 
            this.buttonCONNEXION.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.buttonCONNEXION.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonCONNEXION.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.buttonCONNEXION.FlatAppearance.BorderSize = 0;
            this.buttonCONNEXION.ForeColor = System.Drawing.Color.White;
            this.buttonCONNEXION.Location = new System.Drawing.Point(41, 146);
            this.buttonCONNEXION.Name = "buttonCONNEXION";
            this.buttonCONNEXION.Size = new System.Drawing.Size(135, 43);
            this.buttonCONNEXION.TabIndex = 4;
            this.buttonCONNEXION.Text = "Connexion";
            this.buttonCONNEXION.UseVisualStyleBackColor = false;
            this.buttonCONNEXION.Click += new System.EventHandler(this.buttonCONNEXION_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label2.Location = new System.Drawing.Point(144, 70);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(225, 41);
            this.label2.TabIndex = 11;
            this.label2.Text = "CONNEXION";
            // 
            // textBoxPW
            // 
            this.textBoxPW.Location = new System.Drawing.Point(202, 83);
            this.textBoxPW.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxPW.Name = "textBoxPW";
            this.textBoxPW.Size = new System.Drawing.Size(228, 29);
            this.textBoxPW.TabIndex = 3;
            this.textBoxPW.UseSystemPasswordChar = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(38, 86);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(156, 22);
            this.label4.TabIndex = 2;
            this.label4.Text = "MOT DE PASSE";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 49);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(185, 22);
            this.label3.TabIndex = 1;
            this.label3.Text = "NOM UTILISATEUR";
            // 
            // textBoxUSERNAME
            // 
            this.textBoxUSERNAME.Location = new System.Drawing.Point(202, 46);
            this.textBoxUSERNAME.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxUSERNAME.Name = "textBoxUSERNAME";
            this.textBoxUSERNAME.Size = new System.Drawing.Size(228, 29);
            this.textBoxUSERNAME.TabIndex = 0;
            // 
            // dateTimePickerDATEEXPIRATION
            // 
            this.dateTimePickerDATEEXPIRATION.CustomFormat = "dd/MM/yyyy";
            this.dateTimePickerDATEEXPIRATION.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold);
            this.dateTimePickerDATEEXPIRATION.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerDATEEXPIRATION.Location = new System.Drawing.Point(127, 23);
            this.dateTimePickerDATEEXPIRATION.Name = "dateTimePickerDATEEXPIRATION";
            this.dateTimePickerDATEEXPIRATION.Size = new System.Drawing.Size(173, 26);
            this.dateTimePickerDATEEXPIRATION.TabIndex = 19;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.dateTimePickerDATEEXPIRATION);
            this.panel1.Location = new System.Drawing.Point(30, 8);
            this.panel1.Margin = new System.Windows.Forms.Padding(5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(444, 60);
            this.panel1.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 26.25F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(3, 12);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(438, 41);
            this.label1.TabIndex = 1;
            this.label1.Text = "LABORATOIRE SOLANGE";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.buttonQUITTER);
            this.groupBox1.Controls.Add(this.buttonCONNEXION);
            this.groupBox1.Controls.Add(this.textBoxPW);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.textBoxUSERNAME);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold);
            this.groupBox1.Location = new System.Drawing.Point(13, 115);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(476, 219);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "CONNEXION";
            // 
            // FormLOGIN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(496, 341);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormLOGIN";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CONNEXION";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormLOGIN_FormClosed_1);
            this.Load += new System.EventHandler(this.FormLOGIN_Load_1);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonQUITTER;
        private System.Windows.Forms.Button buttonCONNEXION;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxPW;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxUSERNAME;
        private System.Windows.Forms.DateTimePicker dateTimePickerDATEEXPIRATION;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

