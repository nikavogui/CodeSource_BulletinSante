﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
namespace Labo_Bulletin
{
    class ClassLOGIN
    {
        ClassCONNEXION con = new ClassCONNEXION();
        public DataTable UserConnexion(string username, string pw)
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "SELECT * FROM `cliniquesolange`.`connexion` WHERE userName=@username AND password=@pw;";
            command.Connection = con.GetConnection();
            command.Parameters.Add("@userName", MySqlDbType.VarChar).Value = username;
            command.Parameters.Add("@pw", MySqlDbType.VarChar).Value = pw;
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable table = new DataTable();
            adapter.SelectCommand = command;
            adapter.Fill(table);
            return table;
        }
        public DataTable MDPPERDU(string code)
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "SELECT * FROM `cliniquesolange`.`connexion` WHERE codeSecret=@code;";
            command.Connection = con.GetConnection();
            command.Parameters.Add("@code", MySqlDbType.VarChar).Value = code;
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable table = new DataTable();
            adapter.SelectCommand = command;
            adapter.Fill(table);
            return table;
        }

        public DataTable nbreProduitEnRupture()
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "SELECT * FROM produits where qteStock<=3 AND des<>'MASTER';";
            command.Connection = con.GetConnection();
            //command.Parameters.Add("@date", MySqlDbType.Date).Value = date;
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            adapter.SelectCommand = command;
            DataTable data = new DataTable();
            adapter.Fill(data);
            return data;
        }
    }
}
