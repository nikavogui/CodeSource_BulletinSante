﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using MySql.Data.MySqlClient;

namespace Labo_Bulletin
{
    public partial class Form_LISTE_PARAMETRES : Form
    {
        ClassCONNEXION con = new ClassCONNEXION();
        ReportDocument reportDocument = new ReportDocument();
        public Form_LISTE_PARAMETRES()
        {
            InitializeComponent();
        }

        private void Form_LISTE_PARAMETRES_Load(object sender, EventArgs e)
        {
            try
            {

                //labelMOIS.Hide(); 
                //comboBoxMOIS.Hide();
                //MessageBox.Show(comboBoxMOIS.Text);
                reportDocument.Load(@"C:\Users\DELL\source\repos\Labo_Bulletin\Labo_Bulletin\EXAMENS\ListeParametres.rpt");
                MySqlCommand command = new MySqlCommand();
                command.CommandText = "SELECT idParam, parametre, types, norme, genre, examen FROM parametres;";
                //DateTime day1, day2;
                //day1 = Convert.ToDateTime(dateTimePickerDU.Value);
                //day2 = Convert.ToDateTime(dateTimePickerAU.Value);
                //command.Parameters.Add("@date1", MySqlDbType.Date).Value = day1;
                //command.Parameters.Add("@date2", MySqlDbType.Date).Value = day2;
                command.Connection = con.GetConnection();
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = command;
                DataSet bulletinPerso = new DataSet();
                adapter.Fill(bulletinPerso, "parametres");
                reportDocument.SetDataSource(bulletinPerso);
                // ReportBulletinPaiePerso.SetParameterValue("@mois",comboBoxMOIS.Text);
                crystalReportViewerBULLETINPAIEPERSO.ReportSource = reportDocument;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
