﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Labo_Bulletin
{
    public partial class FormMENUGENERAL : Form
    {
        ClassPATIENTS classPATIENTS = new ClassPATIENTS();
        public FormMENUGENERAL()
        {
            InitializeComponent();
        }

        private void FormMENUGENERAL_FormClosed(object sender, FormClosedEventArgs e)
        {
            FormLOGIN formLOGIN = new FormLOGIN();
            this.Hide();
            formLOGIN.Show();
        }

        private void FormMENUGENERAL_Load(object sender, EventArgs e)
        {
            try
            {
                textBoxCODEPATIENT.Text = "0000";
                textBoxNOM.Text = "";
                textBoxPRENOMS.Text = "";
                maskedTextBoxTELEPHONE.Text = "";
                comboBoxGENRE.Text = "";
                textBoxAGE.Text = "NULL";
                textBoxTEMPERATURE.Text = "NULL";
                textBoxTENSION.Text = "NULL";
                textBoxPOIDS.Text = "NULL";
                textBoxPULSATION.Text = "NULL";

                comboBoxCODEPARAMETRE.DataSource = classPATIENTS.codeParametre();
                comboBoxCODEPARAMETRE.DisplayMember = "idParam";
                comboBoxCODEPARAMETRE.ValueMember = "idParam";
                comboBoxCODEPARAMETRE.Text = "";

                comboBoxNOMPARAMETRE.Text = "";
                comboBoxTITRAGE.Text = "";
                comboBoxNORME.Text = "";
                comboBoxEXAMEN.Text = "";
                comboBoxRESULTAT.Text = "";
                textBoxOBSERVATION.Text = "";

                dataGridViewLISTEEXAMENS.DataSource = classPATIENTS.examenPatient(Convert.ToInt32(textBoxCODEPATIENT.Text));



            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "EXCEPTION ERREUR", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormMENUGENERAL formMENUGENERAL = new FormMENUGENERAL();
            this.Hide();
            formMENUGENERAL.ShowDialog();
        }

        private void comboBoxCODEPARAMETRE_TextChanged(object sender, EventArgs e)
        {
            try
            {
                
                DataTable data = classPATIENTS.InfoParametre(Convert.ToInt32(comboBoxCODEPARAMETRE.Text));
                if (data.Rows.Count > 0)
                {
                    comboBoxNOMPARAMETRE.Text = data.Rows[0][1].ToString();
                    comboBoxTITRAGE.Text = data.Rows[0][2].ToString();
                    comboBoxNORME.Text = data.Rows[0][3].ToString();
                    comboBoxEXAMEN.Text = data.Rows[0][4].ToString();
                }
            }catch(Exception ex)
            {
                //MessageBox.Show(ex.Message, "ERREUR EXCEPTION", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonANNULER_Click(object sender, EventArgs e)
        {
            comboBoxCODEPARAMETRE.DataSource = classPATIENTS.codeParametre();
            comboBoxCODEPARAMETRE.DisplayMember = "idParam";
            comboBoxCODEPARAMETRE.ValueMember = "idParam";
            comboBoxCODEPARAMETRE.Text = "";

            comboBoxNOMPARAMETRE.Text = "";
            comboBoxTITRAGE.Text = "";
            comboBoxNORME.Text = "";
            comboBoxEXAMEN.Text = "";
            comboBoxRESULTAT.Text = "";
            textBoxOBSERVATION.Text = "";

            dataGridViewLISTEEXAMENS.DataSource = classPATIENTS.examenPatient(Convert.ToInt32(textBoxCODEPATIENT.Text));
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(textBoxCODEPATIENT.Text);
                    
                    if (id <= 0)
                    {
                        MessageBox.Show("Patient n'existe pas", "PATIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBoxCODEPATIENT.Text = "0000";
                        textBoxNOM.Select();
                    }
                    else if(textBoxCODEPATIENT.Text.Trim().Equals(""))
                    {
                        MessageBox.Show("Entrer le Code du Patient", "PATIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBoxCODEPATIENT.Text = "0000";
                        textBoxCODEPATIENT.Select();
                    }
                    else
                    {
                        DialogResult result = MessageBox.Show("Confirmer la Suppression du Patient de Code: " + id.ToString(), "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (DialogResult.Yes == result)
                        {
                            bool deleteExamen = classPATIENTS.deletePATIENTANDRESULTAT(id);
                            bool deletePatient = classPATIENTS.deletePATIENT(id);
                            if (deletePatient)
                            {
                                MessageBox.Show("Patient supprimé avec succes", "PATIENT", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            textBoxCODEPATIENT.Text = "0000";
                            textBoxNOM.Text = "";
                            textBoxPRENOMS.Text = "";
                            maskedTextBoxTELEPHONE.Text = "";
                            comboBoxGENRE.Text = "";
                            textBoxAGE.Text = "NULL";
                            textBoxTEMPERATURE.Text = "NULL";
                            textBoxTENSION.Text = "NULL";
                            textBoxPOIDS.Text = "NULL";
                            textBoxPULSATION.Text = "NULL";

                            comboBoxCODEPARAMETRE.DataSource = classPATIENTS.codeParametre();
                                comboBoxCODEPARAMETRE.DisplayMember = "idParam";
                                comboBoxCODEPARAMETRE.ValueMember = "idParam";
                                comboBoxCODEPARAMETRE.Text = "";

                                comboBoxNOMPARAMETRE.Text = "";
                                comboBoxTITRAGE.Text = "";
                                comboBoxNORME.Text = "";
                                comboBoxEXAMEN.Text = "";
                                comboBoxRESULTAT.Text = "";
                                textBoxOBSERVATION.Text = "";

                                dataGridViewLISTEEXAMENS.DataSource = classPATIENTS.examenPatient(Convert.ToInt32(textBoxCODEPATIENT.Text));
                            }
                        }
                    }
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "EXCEPTION ERREUR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(textBoxCODEPATIENT.Text);
                string nom = textBoxNOM.Text.ToUpper();
                string prenoms = textBoxPRENOMS.Text.ToUpper();
                string tel = maskedTextBoxTELEPHONE.Text;
                string genre = comboBoxGENRE.Text.ToUpper();
                string age = (textBoxAGE.Text).ToUpper();
                string temperature = (textBoxTEMPERATURE.Text).ToUpper();
                string tension = (textBoxTENSION.Text).ToUpper();
                string poids = (textBoxPOIDS.Text).ToUpper();
                string pulsation = (textBoxPULSATION.Text).ToUpper();


                if (id <= 0)
                {
                    MessageBox.Show("Patient n'existe pas", "PATIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxCODEPATIENT.Text = "0000";
                    textBoxNOM.Select();
                }
                else if (textBoxCODEPATIENT.Text.Trim().Equals(""))
                {
                    MessageBox.Show("Entrer le Code du Patient", "PATIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxCODEPATIENT.Text = "0000";
                    textBoxCODEPATIENT.Select();
                }else if (nom.Trim().Equals(""))
                {
                    MessageBox.Show("Entrer le Nom du Patient", "PATIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //textBoxCODEPATIENT.Text = "0000";
                    textBoxNOM.Select();
                }
                else if (prenoms.Trim().Equals(""))
                {
                    MessageBox.Show("Entrer le Prenom(s) du Patient", "PATIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //textBoxCODEPATIENT.Text = "0000";
                    textBoxPRENOMS.Select();
                }
                else if (genre.Trim().Equals(""))
                {
                    MessageBox.Show("Selectionner le Genre du Patient", "PATIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //textBoxCODEPATIENT.Text = "0000";
                    comboBoxGENRE.Select();
                }
                else if (textBoxAGE.Text.Trim().Equals(""))
                {
                    MessageBox.Show("Entrer l'Age du Patient", "PATIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxAGE.Text = "0";
                    textBoxAGE.Select();
                }
                else
                {
                    DialogResult result = MessageBox.Show("Confirmer la modification du Patient de Code: " + id.ToString(), "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (DialogResult.Yes == result)
                    {
                       
                        bool maj = classPATIENTS.modifierPatient(id,nom,prenoms,tel,genre,age,temperature,tension,poids,pulsation);
                        if (maj)
                        {
                            MessageBox.Show("Patient enregistré avec succes", "PATIENT", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "EXCEPTION ERREUR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonAJOUTER_Click(object sender, EventArgs e)
        {
           try
            {
                int id = Convert.ToInt32(textBoxCODEPATIENT.Text);
                string nom = textBoxNOM.Text.ToUpper();
                string prenoms = textBoxPRENOMS.Text.ToUpper();
                string tel = maskedTextBoxTELEPHONE.Text;
                string genre = comboBoxGENRE.Text.ToUpper();
                string age = (textBoxAGE.Text).ToUpper();
                string temperature = textBoxTEMPERATURE.Text.ToUpper();
                string tension = (textBoxTENSION.Text).ToUpper();
                string poids = (textBoxPOIDS.Text).ToUpper();
                string pulsation = (textBoxPULSATION.Text).ToUpper();

               
                string parametre = comboBoxNOMPARAMETRE.Text;
                string titrage = comboBoxTITRAGE.Text;
                string norme = comboBoxNORME.Text;
                string examen = comboBoxEXAMEN.Text;
                string resultat = comboBoxRESULTAT.Text.ToUpper();
                string obs = textBoxOBSERVATION.Text.ToUpper();


                if (id == 0)
                {
                 
                   if (nom.Trim().Equals(""))
                    {
                        MessageBox.Show("Entrer le Nom du Patient", "PATIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        //textBoxCODEPATIENT.Text = "0000";
                        textBoxNOM.Select();
                    }
                    else if (prenoms.Trim().Equals(""))
                    {
                        MessageBox.Show("Entrer le Prenom(s) du Patient", "PATIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        //textBoxCODEPATIENT.Text = "0000";
                        textBoxPRENOMS.Select();
                    }
                    else if (genre.Trim().Equals(""))
                    {
                        MessageBox.Show("Selectionner le Genre du Patient", "PATIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        //textBoxCODEPATIENT.Text = "0000";
                        comboBoxGENRE.Select();
                    }
                    else if (textBoxAGE.Text.Trim().Equals(""))
                    {
                        MessageBox.Show("Entrer l'Age du Patient", "PATIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBoxAGE.Text = "0";
                        textBoxAGE.Select();
                    }
                    else if (comboBoxCODEPARAMETRE.Text.Trim().Equals(""))
                    {
                        DialogResult result = MessageBox.Show("Voulez-vous enregistrer le Nouveau Patient sans examen?", "PATIENT", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (result == DialogResult.Yes)
                        {
                            bool ajoutPatient = classPATIENTS.ajoutPatient(nom, prenoms, tel, genre, age, temperature, tension, poids, pulsation);
                            MessageBox.Show("Patient Enregistré avec succes", "PATIENT", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            textBoxCODEPATIENT.Text = "0000";
                            textBoxNOM.Text = "";
                            textBoxPRENOMS.Text = "";
                            maskedTextBoxTELEPHONE.Text = "";
                            comboBoxGENRE.Text = "";
                            textBoxAGE.Text = "NULL";
                            textBoxTEMPERATURE.Text = "NULL";
                            textBoxTENSION.Text = "NULL";
                            textBoxPOIDS.Text = "NULL";
                            textBoxPULSATION.Text = "NULL";

                            comboBoxCODEPARAMETRE.DataSource = classPATIENTS.codeParametre();
                            comboBoxCODEPARAMETRE.DisplayMember = "idParam";
                            comboBoxCODEPARAMETRE.ValueMember = "idParam";
                            comboBoxCODEPARAMETRE.Text = "";

                            comboBoxNOMPARAMETRE.Text = "";
                            comboBoxTITRAGE.Text = "";
                            comboBoxNORME.Text = "";
                            comboBoxEXAMEN.Text = "";
                            comboBoxRESULTAT.Text = "";
                            textBoxOBSERVATION.Text = "";

                            dataGridViewLISTEEXAMENS.DataSource = classPATIENTS.examenPatient(Convert.ToInt32(textBoxCODEPATIENT.Text));
                        }
                        
                    }
                else if (comboBoxCODEPARAMETRE.Text.Trim().Equals(""))
                {
                    MessageBox.Show("Selectionner le Code du Parametre de l'examen", "EXAMEN", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    comboBoxCODEPARAMETRE.Select();
                }
                else if (resultat.Trim().Equals(""))
                    {
                        MessageBox.Show("Selectionner le resultat de l'examen", "EXAMEN", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        comboBoxRESULTAT.Select();
                    }
                    else
                    {
                        DialogResult result = MessageBox.Show("Ajouter l'Examen?","EXAMEN", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (DialogResult.Yes == result)
                        {

                            bool ajoutP = classPATIENTS.ajoutPatient(nom, prenoms, tel, genre, age, temperature, tension, poids, pulsation);
                            if (ajoutP)
                            {
                            int codeParam = Convert.ToInt32(comboBoxCODEPARAMETRE.Text);
                            string codeDernierPatient = classPATIENTS.codeDernierAjout();
                                int dernierPatient = Convert.ToInt32(codeDernierPatient);
                                bool ajoutExamen = classPATIENTS.ajoutResultat(dernierPatient, codeParam, parametre, titrage, norme, examen, resultat, obs);
                                MessageBox.Show("Examen ajouté avec succes", "EXAMEN", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                comboBoxCODEPARAMETRE.DataSource = classPATIENTS.codeParametre();
                                comboBoxCODEPARAMETRE.DisplayMember = "idParam";
                                comboBoxCODEPARAMETRE.ValueMember = "idParam";
                                comboBoxCODEPARAMETRE.Text = "";

                                comboBoxNOMPARAMETRE.Text = "";
                                comboBoxTITRAGE.Text = "";
                                comboBoxNORME.Text = "";
                                comboBoxEXAMEN.Text = "";
                                comboBoxRESULTAT.Text = "";
                                textBoxOBSERVATION.Text = "";

                                dataGridViewLISTEEXAMENS.DataSource = classPATIENTS.examenPatient(dernierPatient);

                                DataTable infosDernierPatient = classPATIENTS.DernierPatientAjout(dernierPatient);

                                textBoxCODEPATIENT.Text = infosDernierPatient.Rows[0][0].ToString();
                                textBoxNOM.Text= infosDernierPatient.Rows[0][1].ToString();
                                textBoxPRENOMS.Text = infosDernierPatient.Rows[0][2].ToString();
                                maskedTextBoxTELEPHONE.Text = infosDernierPatient.Rows[0][3].ToString();
                                comboBoxGENRE.Text = infosDernierPatient.Rows[0][4].ToString();
                                textBoxAGE.Text = infosDernierPatient.Rows[0][5].ToString();
                                textBoxTEMPERATURE.Text = infosDernierPatient.Rows[0][6].ToString();
                                textBoxTENSION.Text = infosDernierPatient.Rows[0][7].ToString();
                                textBoxPOIDS.Text = infosDernierPatient.Rows[0][8].ToString();
                                textBoxPULSATION.Text = infosDernierPatient.Rows[0][9].ToString();



                            }
                        }
                    }
                }else if (id>0)
                {
                if (comboBoxCODEPARAMETRE.Text.Trim().Equals(""))
                {
                    MessageBox.Show("Selectionner le Code du Parametre de l'examen", "EXAMEN", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    comboBoxCODEPARAMETRE.Select();
                }
                    else if (resultat.Trim().Equals(""))
                    {
                        MessageBox.Show("Selectionner le resultat de l'examen", "EXAMEN", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        comboBoxRESULTAT.Select();
                    }
                    else
                {
                    int codeParam = Convert.ToInt32(comboBoxCODEPARAMETRE.Text);
                        DialogResult result = MessageBox.Show("Ajouter l'Examen?", "EXAMEN", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (DialogResult.Yes == result)
                        {

                            bool ajoutExamen = classPATIENTS.ajoutResultat(id, codeParam, parametre, titrage, norme, examen, resultat, obs);
                            MessageBox.Show("Examen ajouté avec succes", "EXAMEN", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            comboBoxCODEPARAMETRE.DataSource = classPATIENTS.codeParametre();
                            comboBoxCODEPARAMETRE.DisplayMember = "idParam";
                            comboBoxCODEPARAMETRE.ValueMember = "idParam";
                            comboBoxCODEPARAMETRE.Text = "";

                            comboBoxNOMPARAMETRE.Text = "";
                            comboBoxTITRAGE.Text = "";
                            comboBoxNORME.Text = "";
                            comboBoxEXAMEN.Text = "";
                            comboBoxRESULTAT.Text = "";
                            textBoxOBSERVATION.Text = "";

                            dataGridViewLISTEEXAMENS.DataSource = classPATIENTS.examenPatient(id);
                        }
                }
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "EXCEPTION ERREUR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBoxCODEPATIENT_Leave(object sender, EventArgs e)
        {
            try
            {
                int codePatient = Convert.ToInt32(textBoxCODEPATIENT.Text);
                if (codePatient != 0)
                {
                    DataTable infosDernierPatient = classPATIENTS.DernierPatientAjout(codePatient);
                    if (infosDernierPatient.Rows.Count > 0)
                    {

                        textBoxCODEPATIENT.Text = infosDernierPatient.Rows[0][0].ToString();
                        textBoxNOM.Text = infosDernierPatient.Rows[0][1].ToString();
                        textBoxPRENOMS.Text = infosDernierPatient.Rows[0][2].ToString();
                        maskedTextBoxTELEPHONE.Text = infosDernierPatient.Rows[0][3].ToString();
                        comboBoxGENRE.Text = infosDernierPatient.Rows[0][4].ToString();
                        textBoxAGE.Text = infosDernierPatient.Rows[0][5].ToString();
                        textBoxTEMPERATURE.Text = infosDernierPatient.Rows[0][6].ToString();
                        textBoxTENSION.Text = infosDernierPatient.Rows[0][7].ToString();
                        textBoxPOIDS.Text = infosDernierPatient.Rows[0][8].ToString();
                        textBoxPULSATION.Text = infosDernierPatient.Rows[0][9].ToString();

                        dataGridViewLISTEEXAMENS.DataSource = classPATIENTS.examenPatient(codePatient);

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "EXCEPTION ERREUR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBoxCODEPATIENT.Text = "0000";
                textBoxCODEPATIENT.Select();
            }
        }

        private void dataGridViewLISTEEXAMENS_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                textBoxIDRESULTAT.Text = dataGridViewLISTEEXAMENS.CurrentRow.Cells[0].Value.ToString();


                if (textBoxIDRESULTAT.Text.Trim().Equals(""))
                {
                    labelSUPPRESSIONPRETE.Text ="Aucun element selectionné dans le tableau";
                    dataGridViewLISTEEXAMENS.Select();
                }
                else
                {
                    
                    labelSUPPRESSIONPRETE.Text = "Une ligne ligne selectionnée dans le tableau";
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "EXCEPTION ERREUR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBoxCODEPATIENT.Text = "0000";
                textBoxCODEPATIENT.Select();
            }
}

        private void buttonSUPPRIMER_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(textBoxIDRESULTAT.Text);

                    DialogResult result = MessageBox.Show("Confirmer la Suppression de l'examen", "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (DialogResult.Yes == result)
                    {
                        bool deleteExamen = classPATIENTS.deleteResultat(id);
                        if (deleteExamen)
                        {
                            MessageBox.Show("Examen supprimé avec succes", "EXAMEN", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            dataGridViewLISTEEXAMENS.DataSource = classPATIENTS.examenPatient(Convert.ToInt32(textBoxCODEPATIENT.Text));
                        }
                    }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "EXCEPTION ERREUR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonLISTEPARAMETRE_Click(object sender, EventArgs e)
        {
            Form_LISTE_PARAMETRES form_LISTE_PARAMETRES = new Form_LISTE_PARAMETRES();
            form_LISTE_PARAMETRES.ShowDialog();
        }

        private void buttonBULLETIN_Click(object sender, EventArgs e)
        {
            Form_BULLETIN form_BULLETIN = new Form_BULLETIN(Convert.ToInt32(textBoxCODEPATIENT.Text));
            form_BULLETIN.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form_LISTE_PATIENTS form_LISTE_PATIENTS = new Form_LISTE_PATIENTS();
            form_LISTE_PATIENTS.ShowDialog();
        }
    }
}
